import { Routes } from '@angular/router';
import { UserDashboard } from './user-dashboard/user-dashboard';

export const USER_ROUTES: Routes = [
  { path: '', component: UserDashboard},
];

import { Routes } from '@angular/router';
import { AdminDashboard } from './admin-dashboard/admin-dashboard';
import { Layout } from './layouts/layout/layout';

export const ADMIN_ROUTES: Routes = [
  { path: 'layout', component: Layout,
    children: [
      { path: '', component: AdminDashboard},
    ],
  },
];
